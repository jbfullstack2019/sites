console.log("start");


var num = parseFloat(prompt("Please insert a number"));


// if(num < 0) {
//     alert("neg");
// } else if(num == 0) {
//     alert("zero");
// } else {
//     alert("pos");
// }



// if(num <= 0) {
//     if(num == 0) {
//         alert("zero");
//     } else {
//         alert("neg");
//     }
// } else {
//     alert("pos");
// }


// if(num < 0) {
//     alert("neg");
// } else {
//     if(num == 0) {
//         alert("zero");
//     } else {
//         alert("pos");
//     }
// }


console.log("end")