function myTask() {
    document.getElementById("myImgToShow").src = document.getElementById("myImgToCath").value;
}