var num = 4;
num = new Number(4);

var str = "Noam";
str = new String("Noam");

var bool = true;
bool = new Boolean(true);

var arr = [12,23,34,45];
arr = new Array(12,23,34,45);

var obj = {name: "Noam", age: 12};
obj = new Object();
obj.name = "Noam";
obj.age = 12;


