var arr = [
    12, 
    89
];

arr[1] = 4;
arr[2] = "Noam";
arr[3] = true;

arr[4] = "Tahan";


for (var index = 0; index < arr.length; index++) {
    console.log(arr[index]);
    
}

